package com.example.myrecyclerview.model;

import com.example.myrecyclerview.R;

import java.util.ArrayList;

public class PlacesData {
    private static String[] placesName = {
            "Pangeran Antasari (1797-1862)",
            "Panglima Batur (1820-1863)",
            "Ngabe Anom Soekah (1850-1912)",
            "Tumenggung Surapati (1771-1875)",
            "Tjilik Riwut (1918-1986)",
            "Panglima Wangkang (1812-1872)",
            "Sultan Hidayatullah II (1822-1904)",
            "Ir. Pangeran H. Mohammad Noor (1901-1979)",
            "Idham Chalid (1921-2010)",
            "Brigjen Hasan Basry (1923-1984)",
            "Abdul Kadir (1771-1875 )",
            "Drs, Saadillah Mursjid (1937-2005).",


    };

    private static String[] placesDetail = {
            "Pangeran Antasari adalah seorang pemimpin pejuang Dayak melawan penjajahan Belanda di Kalimantan Selatan. Ia lahir di Martapura, Kalimantan Selatan, pada tahun 1797.\n" +
                    "\n" +
                    "Pangeran Antasari memimpin perlawanan rakyat Dayak selama bertahun-tahun. Ia berhasil menyatukan berbagai suku Dayak untuk melawan Belanda.\n" +
                    "\n" +
                    "Pangeran Antasari meninggal pada tahun 1862 dalam pertempuran melawan Belanda. Ia dimakamkan di Makam Pahlawan Antasari di Banjarmasin.\n",

            "Panglima Batur adalah seorang pemimpin pejuang Dayak melawan penjajahan Belanda di Kalimantan Selatan. Ia lahir di Desa Batur, Kalimantan Selatan, pada tahun 1820.\n" +
                    "\n" +
                    "Panglima Batur dikenal sebagai pemimpin yang pemberani dan cerdas. Ia memimpin perlawanan rakyat Dayak selama bertahun-tahun.\n" +
                    "\n" +
                    "Panglima Batur ditangkap oleh Belanda pada tahun 1862 dan dihukum mati. Ia meninggal di Banjarmasin pada tahun 1863.\n" ,

            "Ngabe Anom Soekah adalah seorang pemimpin pejuang Dayak melawan penjajahan Belanda di Kalimantan Tengah. Ia lahir di Pahandut, Kalimantan Tengah, pada tahun 1850.\n" +
                    "\n" +
                    "Ngabe Anom Soekah dikenal sebagai pemimpin yang bijaksana, berani, dan memiliki kepedulian sosial yang tinggi. Ia memimpin perlawanan terhadap Belanda selama bertahun-tahun.\n" +
                    "\n" +
                    "Salah satu pertempuran yang terkenal adalah pertempuran di Sungai Barito pada tahun 1904. Dalam pertempuran itu, pasukan Ngabe Anom Soekah berhasil mengalahkan pasukan Belanda.\n" +
                    "\n" +
                    "Ngabe Anom Soekah ditangkap oleh Belanda pada tahun 1905 dan dibuang ke Ambon. Ia meninggal di Ambon pada tahun 1912.\n" ,
            "Tumenggung Surapati adalah seorang pemimpin pejuang Dayak melawan penjajahan Belanda di Kalimantan Barat. Ia lahir di Kab. Sintang Propinsi Kalimantan Barat pada tahun 1771.\n" +
                    "\n" +
                    "Tumenggung Surapati dikenal sebagai pemimpin yang pemberani dan cerdas. Ia memimpin perlawanan terhadap Belanda selama bertahun-tahun.\n" +
                    "\n" +
                    "Salah satu pertempuran yang terkenal adalah pertempuran di Muara Teweh pada tahun 1865. Dalam pertempuran itu, pasukan Tumenggung Surapati berhasil mengalahkan pasukan Belanda.\n" +
                    "\n" +
                    "Tumenggung Surapati ditangkap oleh Belanda pada tahun 1866 dan dibuang ke Ambon. Ia meninggal di Ambon pada tahun 1875.\n" ,

            "Tjilik Riwut adalah seorang tokoh pejuang dan pahlawan nasional asal Kalimantan Tengah. Ia lahir di Puruk Cahu, Kalimantan Tengah, pada tahun 1918.\n" +
                    "\n" +
                    "Tjilik Riwut dikenal sebagai tokoh yang gigih memperjuangkan hak-hak masyarakat Dayak. Ia juga berperan penting dalam memperjuangkan kemerdekaan Indonesia.\n" +
                    "\n" +
                    "Tjilik Riwut pernah menjabat sebagai Gubernur Kalimantan Tengah dan Menteri Dalam Negeri. Ia juga pernah menjadi Duta Besar Indonesia untuk Australia.\n" +
                    "\n" +
                    "Tjilik Riwut meninggal pada tahun 1986. Ia dimakamkan di Makam Pahlawan Pancasila di Palangka Raya.\n" ,

            "Panglima Wangkang adalah seorang panglima perang dalam Perang Banjar dari kalangan suku Bakumpai yang mempertahankan Distrik Bakumpai (sekarang Barito Kuala). Ia lahir di Marabahan pada tahun 1812 dan wafat pada tahun 1872.\n" +
                    "\n" +
                    "Panglima Wangkang merupakan panglima Dayak yang berdarah Banjar. Ayahnya bernama Kendet (Pambakal Kendet), juga seorang pejuang dan pemimpin suku Bakumpai. Ibunya bernama Ulan berasal dari Amuntai seorang suku Banjar.\n" +
                    "\n" +
                    "Panglima Wangkang dikenal sebagai sosok yang gigih dan berani. Ia memimpin perlawanan terhadap Belanda di wilayah Bakumpai selama bertahun-tahun. Ia juga dikenal sebagai sosok yang cerdas dan memiliki strategi perang yang jitu.\n" +
                    "\n" +
                    "Salah satu pertempuran yang terkenal yang dipimpin oleh Panglima Wangkang adalah pertempuran di Sungai Durrakhman pada tahun 1870. Dalam pertempuran tersebut, Panglima Wangkang berhasil mengalahkan pasukan Belanda yang dipimpin oleh Kapten Van der Pijl.\n" +
                    "\n" +
                    "Panglima Wangkang akhirnya ditangkap oleh Belanda pada tahun 1872. Ia kemudian dihukum mati di Marabahan.",

            "Sultan Hidayatullah II, terlahir dengan nama Gusti Andarun, dengan gelar mangkubumi Pangeran Hidayatullah kemudian bergelar Sultan Hidayatullah Halil Illah, adalah pemimpin Kesultanan Banjar yang memerintah antara tahun 1859 sampai 1862. Ia dikenal sebagai salah seorang tokoh pemimpin Perang Banjar melawan pemerintahan Hindia Belanda.\n" +
                    "\n" +
                    "Sultan Hidayatullah II lahir di Martapura, Kalimantan Selatan, pada tahun 1822. Ia adalah putra dari Pangeran Ratu Sultan Muda Abdurrahman dan Ratu Siti. Ayahnya adalah putra dari Sultan Adam Al-Watsiq Billah, sultan ke-17 Kesultanan Banjar.\n" +
                    "\n" +
                    "Pada tahun 1859, terjadi perebutan takhta Kesultanan Banjar antara Pangeran Antasari dan Pangeran Hidayatullah. Pangeran Antasari didukung oleh Belanda, sedangkan Pangeran Hidayatullah didukung oleh rakyat Banjar. Pada akhirnya, Pangeran Hidayatullah berhasil dinobatkan sebagai sultan pada tanggal 24 September 1859.\n" +
                    "\n" +
                    "Pangeran Hidayatullah memimpin Perang Banjar melawan Belanda selama kurang lebih tiga tahun. Ia berhasil memobilisasi rakyat Banjar untuk melawan Belanda. Perang Banjar berlangsung dengan sengit dan memakan korban yang banyak di kedua belah pihak.\n" +
                    "\n" +
                    "Pada tahun 1862, Pangeran Hidayatullah dan keluarganya berhasil ditangkap oleh Belanda. Pangeran Hidayatullah dibuang ke Cianjur, Jawa Barat, dan meninggal dunia di sana pada tahun 1904.\n" +
                    "\n" +
                    "Sultan Hidayatullah II merupakan salah satu tokoh pejuang kemerdekaan Indonesia. Ia telah mengorbankan jiwa dan raganya untuk memperjuangkan kemerdekaan Kesultanan Banjar dari penjajahan Belanda.",

            "Ir. Pangeran H. Mohammad Noor adalah seorang pejuang kemerdekaan dan tokoh pembangunan Kalimantan. Ia lahir di Martapura, Kalimantan Selatan, pada tanggal 24 Juni 1901. Ia merupakan putra dari Pangeran Ali dan Ratu Intan. Kedua orangtuanya adalah keturunan bangsawan Banjar.\n" +
                    "\n" +
                    "Mohammad Noor memulai pendidikannya di Sekolah Dasar Martapura, kemudian melanjutkan ke Sekolah Menengah Pertama di Banjarmasin. Setelah lulus dari SMP, ia melanjutkan pendidikannya ke Sekolah Teknik Tinggi (ST) di Bandung. Ia lulus dari ST pada tahun 1923 dengan gelar Insinyur Sipil.\n" +
                    "\n" +
                    "Setelah lulus dari ST, Mohammad Noor bekerja sebagai insinyur di Dinas Pekerjaan Umum Kalimantan. Ia kemudian diangkat menjadi kepala dinas tersebut pada tahun 1939.\n" +
                    "\n" +
                    "Pada masa pendudukan Jepang, Mohammad Noor tetap bekerja di Dinas Pekerjaan Umum. Ia juga aktif dalam gerakan bawah tanah melawan penjajah.\n" +
                    "\n" +
                    "Setelah proklamasi kemerdekaan, Mohammad Noor diangkat menjadi Gubernur Kalimantan pertama. Ia menjabat sebagai gubernur dari tahun 1945 hingga 1949. Selama menjabat sebagai gubernur, Mohammad Noor berhasil menyatukan kekuatan pejuang kemerdekaan di Kalimantan dan mempertahankan wilayah Kalimantan dari serangan Belanda. \n" +
                    "Gambar Ir. Pangeran H. Mohammad NoorTerbuka di jendela baru\n" +
                    "id.wikipedia.org\n" +
                    "Ir. Pangeran H. Mohammad Noor\n" +
                    "\n" +
                    "Pada tahun 1956, Mohammad Noor diangkat menjadi Menteri Pekerjaan Umum dalam Kabinet Ali Sastroamidjojo II. Ia menjabat sebagai menteri hingga tahun 1959. Selama menjabat sebagai menteri, Mohammad Noor berhasil merampungkan pembangunan beberapa proyek penting, seperti PLTA Riam Kanan dan Proyek Pasang Surut.\n" +
                    "\n" +
                    "Mohammad Noor adalah seorang tokoh yang memiliki jasa yang besar bagi bangsa Indonesia, khususnya bagi Kalimantan. Ia dianugerahi gelar Pahlawan Nasional pada tanggal 8 November 2018.",

            "Idham Chalid adalah seorang tokoh bangsa, tokoh agama, tokoh organisasi besar Islam Nahdlatul Ulama (NU), dan juga deklarator sekaligus pemimpin Partai Persatuan Pembangunan (PPP). Ia lahir di Satui, Kalimantan Selatan, pada tanggal 27 Agustus 1921, dan meninggal di Jakarta pada tanggal 11 Juli 2010.\n" +
                    "\n" +
                    "Idham Chalid memulai kariernya sebagai aktivis Gerakan Pemuda Ansor, organisasi sayap pemuda NU. Ia kemudian terpilih sebagai Sekretaris Jenderal Pengurus Besar Nahdlatul Ulama (PBNU) periode kepemimpinan KH Maskur. Sejak tahun 1956, ia menjabat sebagai Ketua Umum PBNU sampai tahun 1984.\n" +
                    "\n" +
                    "Dalam bidang politik, Idham Chalid pernah menjabat sebagai Wakil Perdana Menteri Indonesia pada Kabinet Ali Sastroamidjojo II dan Kabinet Burhanuddin Harahap. Ia juga pernah menjabat sebagai Ketua Majelis Permusyawaratan Rakyat (MPR) pada tahun 1971-1977.",

            "Brigjen Hasan Basry adalah seorang tokoh militer dan Pahlawan nasional Indonesia. Ia lahir di Kandangan, Kalimantan Selatan, pada tanggal 17 Juni 1923.\n" +
                    "\n" +
                    "Hasan Basry memulai karier militernya sebagai anggota Tentara Keamanan Rakyat (TKR) pada tahun 1945. Ia kemudian menjadi salah satu tokoh penting dalam perjuangan kemerdekaan Indonesia di Kalimantan Selatan.\n" +
                    "\n" +
                    "Pada tahun 1947, Hasan Basry mendirikan Batalyon ALRI Divisi IV di Kalimantan Selatan. Batalyon ini kemudian menjadi salah satu kekuatan utama dalam perjuangan kemerdekaan di Kalimantan Selatan.\n" +
                    "\n" +
                    "Hasan Basry juga berperan penting dalam memimpin gerilya rakyat Kalimantan Selatan melawan Belanda. Ia berhasil memimpin pasukannya untuk merebut kembali sejumlah wilayah yang dikuasai Belanda.",

            "Memiliki nama lain sebagai Raden Temenggung Setia Pahlawan, Abdul Kadir lahir pada 1771 di Kab. Sintang Propinsi Kalimantan Barat. Beliau wafat pada 1875 di Kab. Melawi, Kalimantan Barat. Beliau merupakan seorang bangsawan dari Melawi yang menawarkan pengembangan ekonomi rakyatnya sekaligus melawan pasukan Belanda.\n" +
                    "\n" +
                    "Abdul Kadir adalah putra dari seorang bangsawan kerajaan Sintang yang memimpin wilayah Melawi pada tahun 1845 menggantikan ayahnya. Abdul Kadir berada dalam kondisi dilematis karena harus patuh kepada raja yang tuduk kepada Belanda, tetapi jiwanya tidak bisa mengingkari penolakan terhadap penjajahan Belanda.\n" +
                    "\n" +
                    "Beliau kemudian membangun pasukan secara diam–diam untuk bersiap melawan Belanda. Belanda yang mengetahui rencana tersebut dan memberinya gelar Setia Pahlawan beserta sejumlah uang pada tahun 1866,tetapi Abdul Kadir tetap melanjutkan perlawanannya dari tahun 1868-1875. Belanda selalu kalah karena Abdul Kadir selalu mendapatkan informasi, akhirnya beliau ditangkap oleh Belanda dan ditahan di Nanga Pinoh hingga wafat dalam tahanan dan dimakamkan di Natal Mungguk Liang, Melawi. Abdul Kadir memperoleh gelar sebagai pahlawan nasional pada tahun 1999.",

            "Drs, Saadillah Mursjid lahir pada tanggal 7 September 1937 dan wafat pada tanggal 28 Juli 2005. Beliau adalah Menteri Muda/Sekretaris Kabinet Indonesia pada Kabinet Pembangunan V, Menteri Sekretaris Kabinet pada Kabinet Pembangunan VI, dan Menteri Sekretaris Negara pada Kabinet Pembangunan VII.\n" +
                    "\n" +
                    "Sebelum mendapatkan posisi menteri, Drs. Saadilah Mursyid sebagai lulusan Universitas Gadjah Mada, The Netherlands Economic Institute (Rotterdam), dan Universitas Harvard ini pernah bertugas di Badan Perencanaan Pembangunan Nasional (Bappenas). Pada tahun 1992, beliau memperoleh penghargaan Bintang Mahaputra Adipradana. Sejak tahun 2003, Drs. Saadilah Mursyid menjadi general manager Taman Mini Indonesia Indah.\n" +
                    "\n" +
                    "Beliau menjabat sebagai Menteri Sekretaris Negara saat pengunduran diri mantan Presiden Soeharto. Pada masa itu Soeharto menunjuk Drs. Saadilah Mursyid untuk mempersiapkan naskah final Keputusan Presiden mengenai Komite Reformasi dan Keputusan Presiden mengenai Pembentukan Kabinet Reformasi. Drs. Saadilah Mursyid juga dikenal sebagai politisi pengikut Soeharto yang loyal serta tetap mendampingi Soeharto ketika banyak orang berpaling dari Soeharto setelah kejatuhannya. Beliau adalah orang yang menulis konsep pengunduran diri Presiden Soeharto serta melaporkan detik-detik suasana genting pada Mei 1998.",






    };

    private static int[] placesPhoto = {
            R.drawable.antarasi,
            R.drawable.batur,
            R.drawable.ngabe,
            R.drawable.suropati,
            R.drawable.riwut,
            R.drawable.wangkang,
            R.drawable.sultan,
            R.drawable.noor,
            R.drawable.idham,
            R.drawable.hasan,
            R.drawable.abdul,
            R.drawable.saadillah,

    };

    public static ArrayList<Place> getListData() {
        ArrayList<Place> list = new ArrayList<>();
        for (int i = 0; i < placesName.length; i++) {
            Place place = new Place();
            place.setName(placesName[i]);
            place.setDetail(placesDetail[i]);
            place.setPhoto(placesPhoto[i]);
            list.add(place);
        }
        return list;
    }

    public Place getData(int id) {
        Place place = new Place();
        place.setName(placesName[id]);
        place.setDetail(placesDetail[id]);
        place.setPhoto(placesPhoto[id]);
        return place;
    }
}
